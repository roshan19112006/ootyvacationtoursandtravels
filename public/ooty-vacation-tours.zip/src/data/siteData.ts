export const CONTACTS = {
  ashraf: { name: "Ashraf", phone: "918056681851", displayPhone: "8056681851" },
  zubair: { name: "Zubair – Auto", phone: "919487069607", displayPhone: "9487069607" },
  samsudheen: { name: "Samsudheen – Homestay", phone: "919843173355", displayPhone: "+91 98431 73355" },
  email: "1212ashrafashu@gmail.com",
};

export const WHATSAPP_DEFAULT = CONTACTS.ashraf.phone;

export function whatsappLink(
  phone: string = WHATSAPP_DEFAULT,
  message?: string,
): string {
  const base = `https://wa.me/${phone}`;
  if (message) return `${base}?text=${encodeURIComponent(message)}`;
  return base;
}

export function callLink(phone: string): string {
  return `tel:+${phone}`;
}

export interface Destination {
  name: string;
  slug: string;
  tagline: string;
  description: string;
  image: string;
}

export const DESTINATIONS: Destination[] = [
  {
    name: "Ooty",
    slug: "ooty",
    tagline: "Queen of the Nilgiris",
    description:
      "Discover the breathtaking beauty of Ooty with its rolling tea gardens, serene lakes, and misty mountain views.",
    image: "https://images.unsplash.com/photo-1739323019516-78a6be75d0bb?w=800&q=80",
  },
  {
    name: "Kodaikanal",
    slug: "kodaikanal",
    tagline: "Princess of Hill Stations",
    description:
      "Explore Kodaikanal's misty peaks, crystal-clear lakes, lush forests, and stunning viewpoints.",
    image: "https://images.unsplash.com/photo-1596394723269-e1b58a1e6d8a?w=800&q=80",
  },
  {
    name: "Wayanad",
    slug: "wayanad",
    tagline: "Nature & Wildlife",
    description:
      "Experience Wayanad's ancient caves, pristine dams, wildlife sanctuaries, and lush green landscapes.",
    image: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800&q=80",
  },
  {
    name: "Mysore",
    slug: "mysore",
    tagline: "Palaces & Heritage",
    description:
      "Discover the royal heritage of Mysore with its magnificent palace, gardens, temples, and cultural charm.",
    image: "https://images.unsplash.com/photo-1600100397608-e1e5e3c7e4e3?w=800&q=80",
  },
  {
    name: "Coorg",
    slug: "coorg",
    tagline: "Coffee, Hills & Nature",
    description:
      "Immerse yourself in Coorg's coffee plantations, misty hills, waterfalls, and rich cultural heritage.",
    image: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800&q=80",
  },
  {
    name: "Coonoor",
    slug: "coonoor",
    tagline: "Tea Gardens & Mountain Views",
    description:
      "Explore Coonoor's scenic viewpoints, tea estates, parks, and tranquil mountain vistas.",
    image: "https://images.unsplash.com/photo-1556679343-c7306c1976bc?w=800&q=80",
  },
];

export interface SightseeingPlace {
  name: string;
  description: string;
  image: string;
}

export const OOTY_SIGHTSEEING: SightseeingPlace[] = [
  { name: "Doddabetta Peak", description: "Highest point in the Nilgiris offering panoramic mountain views.", image: "/assets/121.jpg" },
  { name: "Tea Museum", description: "Discover the history and art of tea making in Ooty.", image: "/assets/212.jpg" },
  { name: "Wax Museum", description: "Life-size wax figures of famous personalities.", image: "/assets/313.jpg" },
  { name: "Botanical Garden", description: "A centuries-old garden with rare plants and floral displays.", image: "/assets/41.jpg" },
  { name: "Rose Garden", description: "Home to thousands of rose varieties in stunning colors.", image: "/assets/51.jpg" },
  { name: "Thread Garden", description: "Unique garden featuring flowers made entirely from thread.", image: "/assets/61.jpg" },
  { name: "Ooty Lake", description: "Serene lake perfect for boating and scenic views.", image: "/assets/71.jpg" },
];

export const COONOOR_SIGHTSEEING: SightseeingPlace[] = [
  { name: "Valley View", description: "Breathtaking panoramic views of the Nilgiri valleys.", image: "/assets/kv.jpg" },
  { name: "MRC Outer View", description: "Scenic viewpoint offering stunning natural landscapes.", image: "/assets/kv1.jpg" },
  { name: "Golf View", description: "Picturesque view of the Coonoor Golf Course.", image: "/assets/kv2.jpg" },
  { name: "Sims Park", description: "A beautiful botanical park with exotic plant species.", image: "/assets/kv3.jpg" },
  { name: "Tea Garden", description: "Lush tea plantations with stunning valley views.", image: "/assets/kv4.jpg" },
  { name: "Lamb's Rock", description: "A popular viewpoint offering views of Coimbatore plains.", image: "/assets/kv5.jpg" },
  { name: "Dolphin's Nose View", description: "Unique rock formation resembling a dolphin's nose with stunning views.", image: "/assets/kv6.jpg" },
];

export const PYKARA_SIGHTSEEING: SightseeingPlace[] = [
  { name: "Golf View", description: "Scenic golf course views amidst the hills.", image: "/assets/pk1.jpg" },
  { name: "Pine Forest", description: "Towering pine trees creating a magical atmosphere.", image: "/assets/pk2.jpg" },
  { name: "Tree Park", description: "A natural park with diverse tree species and trails.", image: "/assets/pk3.jpg" },
  { name: "Shooting Spot", description: "Famous film shooting location amid beautiful landscapes.", image: "/assets/pk4.jpg" },
  { name: "Pykara Lake", description: "Tranquil lake surrounded by dense forests.", image: "/assets/pk5.jpg" },
  { name: "Pykara Waterfalls", description: "Cascading waterfalls in a lush green setting.", image: "/assets/pk6.jpg" },
];

export const AVALANCHE_SIGHTSEEING: SightseeingPlace[] = [
  { name: "Carnhill Forest", description: "Dense forest with rich biodiversity and nature trails.", image: "/assets/a1.jpg" },
  { name: "Emerald Lake Outer View", description: "Stunning views of the crystal-clear Emerald Lake.", image: "/assets/a2.jpg" },
  { name: "Avalanche Lake", description: "Pristine lake nestled in a stunning mountain valley.", image: "/assets/a3.jpg" },
  { name: "Avalanche Safari", description: "Wildlife safari through the Avalanche reserve forest.", image: "/assets/a4.jpg" },
  { name: "Karnataka Garden", description: "Beautiful garden maintained by Karnataka Forest Department.", image: "/assets/a5.jpg" },
];

export const KODAIKANAL_SIGHTSEEING: SightseeingPlace[] = [
  { name: "Green Valley View Point", description: "Spectacular panoramic views of the Vaigai Dam and plains.", image: "/assets/q1.jpg" },
  { name: "Guna Caves", description: "Mysterious caves also known as Devil's Kitchen.", image: "/assets/q2.jpg" },
  { name: "Pine Forest", description: "Towering pine trees creating a serene atmosphere.", image: "/assets/q3.jpg" },
  { name: "Pillar Rocks", description: "Three giant rock pillars standing 122 meters high.", image: "/assets/q4.jpg" },
  { name: "Coaker's Walk", description: "Scenic pedestrian path with stunning valley views.", image: "/assets/q5.jpg" },
  { name: "Bryant Park", description: "Well-maintained botanical garden with rare plants.", image: "/assets/q6.jpg" },
  { name: "Kodaikanal Lake", description: "Star-shaped lake perfect for boating and nature walks.", image: "/assets/q7.jpg" },
];

export const WAYANAD_SIGHTSEEING: SightseeingPlace[] = [
  { name: "Edakkal Caves", description: "Ancient caves with prehistoric petroglyphs and stunning views.", image: "/assets/p1.jpg" },
  { name: "Karapuzha Dam", description: "Picturesque dam surrounded by lush greenery.", image: "/assets/p2.jpg" },
  { name: "Banasura Dam", description: "Largest earth dam in India with stunning backwaters.", image: "/assets/p3.jpg" },
  { name: "Pookode Lake", description: "Natural freshwater lake amidst dense forests.", image: "/assets/p4.jpg" },
];

export const MYSORE_SIGHTSEEING: SightseeingPlace[] = [
  { name: "Mysore Palace", description: "Magnificent royal palace showcasing Indo-Saracenic architecture.", image: "/assets/m1.jpg" },
  { name: "Mysore Zoo", description: "One of the oldest and best zoos in India.", image: "/assets/m2.jpg" },
  { name: "Fish Aquarium", description: "A diverse collection of freshwater and marine fish.", image: "/assets/m3.jpg" },
  { name: "Chamundeshwari Temple", description: "Historic temple atop Chamundi Hills with city views.", image: "/assets/m4.jpg" },
  { name: "Sand Museum", description: "Intricate sculptures crafted entirely from sand.", image: "/assets/m5.jpg" },
  { name: "St. Philomena's Church", description: "One of the tallest churches in Asia with Gothic architecture.", image: "/assets/m6.jpg" },
  { name: "Brindavan Gardens", description: "Famous terraced garden with musical fountain shows.", image: "/assets/m7.jpg" },
];

export interface TourPackage {
  id: string;
  title: string;
  duration: string;
  slug: string;
  description: string;
  highlights: string[];
  itinerary: { day: number; title: string; details: string }[];
  image: string;
}

export const PACKAGES: TourPackage[] = [
  {
    id: "2d1n",
    title: "Ooty 2D/1N Tour Package",
    duration: "2 Days / 1 Night",
    slug: "ooty-tour-packages",
    description: "Perfect short getaway covering the best of Ooty with comfortable sightseeing and accommodation.",
    highlights: ["Ooty Local Sightseeing", "Coonoor/Pykara Tour", "Hotel Stay", "Transport Included"],
    itinerary: [
      { day: 1, title: "Ooty Pickup → Ooty Local Sightseeing → Hotel Drop", details: "Doddabetta Peak, Tea Museum, Botanical Garden, Rose Garden, Thread Garden, Ooty Lake, Wax Museum." },
      { day: 2, title: "Hotel Pickup → Coonoor / Pykara Sightseeing → Ooty Drop", details: "Explore Coonoor or Pykara scenic spots before returning to Ooty." },
    ],
    image: "/assets/1111.jpeg",
  },
  {
    id: "2d1n-alt",
    title: "Ooty 2-Day Complete Package",
    duration: "2 Days / 1 Night",
    slug: "ooty-tour-packages",
    description: "Want to cover all major places in Ooty in 2 days? Here you go!",
    highlights: ["Pykara + Half Ooty Day 1", "Coonoor + Remaining Ooty Day 2", "Hotel Stay", "Transport Included"],
    itinerary: [
      { day: 1, title: "Ooty Pickup → Pykara + Half Ooty Sightseeing → Hotel", details: "Pykara Lake, Waterfalls, Pine Forest, and half of Ooty's attractions." },
      { day: 2, title: "Hotel Pickup → Coonoor Sightseeing + Remaining Ooty Places → Ooty Drop", details: "Complete Coonoor sightseeing and remaining Ooty attractions." },
    ],
    image: "/assets/222.jpg",
  },
  {
    id: "3d2n",
    title: "Ooty 3D/2N Tour Package",
    duration: "3 Days / 2 Nights",
    slug: "ooty-tour-packages",
    description: "The most popular package covering Ooty, Pykara, and Coonoor with comfortable hotel stays.",
    highlights: ["Ooty Local Sightseeing", "Pykara/Mudumalai Tour", "Coonoor Sightseeing", "2 Hotel Nights"],
    itinerary: [
      { day: 1, title: "Ooty Local Pickup → Ooty Local Sightseeing → Hotel Drop", details: "Explore all major Ooty attractions at your own pace." },
      { day: 2, title: "Hotel Pickup → Pykara / Mudumalai Sightseeing → Hotel", details: "Visit Pykara Lake, Waterfalls, Pine Forest and optionally Mudumalai." },
      { day: 3, title: "Hotel Pickup → Coonoor Sightseeing → Ooty Drop", details: "Full Coonoor sightseeing including viewpoints, tea gardens, and parks." },
    ],
    image: "/assets/333.jpg",
  },
  {
    id: "4d3n",
    title: "Ooty 4D/3N Tour Package",
    duration: "4 Days / 3 Nights",
    slug: "ooty-tour-packages",
    description: "An extended Ooty tour covering all attractions including Avalanche and Kotagiri.",
    highlights: ["Ooty Sightseeing", "Pykara/Mudumalai", "Coonoor Tour", "Avalanche/Kotagiri", "3 Hotel Nights"],
    itinerary: [
      { day: 1, title: "Ooty Local Pickup → Ooty Local Sightseeing → Hotel", details: "Cover major Ooty attractions." },
      { day: 2, title: "Hotel Pickup → Pykara / Mudumalai Sightseeing → Hotel", details: "Explore Pykara and optionally Mudumalai wildlife." },
      { day: 3, title: "Hotel Pickup → Coonoor Sightseeing → Hotel", details: "Full Coonoor sightseeing tour." },
      { day: 4, title: "Hotel Pickup → Avalanche / Kotagiri Sightseeing → Ooty Drop", details: "Explore Avalanche or Kotagiri's hidden gems." },
    ],
    image: "/assets/444.jpg",
  },
  {
    id: "ooty-kodaikanal",
    title: "Ooty & Kodaikanal Tour Package",
    duration: "5 Days / 4 Nights",
    slug: "kodaikanal-tour-packages",
    description: "Explore two of South India's most beautiful hill stations — Ooty and Kodaikanal.",
    highlights: ["2 Nights Ooty", "2 Nights Kodaikanal", "Coonoor Sightseeing", "Kodaikanal Sightseeing"],
    itinerary: [
      { day: 1, title: "Coimbatore Pickup → Drive to Ooty → Half-day Pykara Sightseeing → Hotel", details: "Airport/railway pickup, scenic drive to Ooty, Pykara exploration." },
      { day: 2, title: "Ooty Hotel Pickup → Ooty Local Sightseeing → Hotel", details: "Full day Ooty sightseeing." },
      { day: 3, title: "Hotel Checkout → Coonoor Sightseeing → Drive to Kodaikanal → Hotel", details: "Coonoor on the way, then drive to Kodaikanal." },
      { day: 4, title: "Kodaikanal Hotel Pickup → Local Sightseeing → Hotel", details: "Green Valley View, Guna Caves, Pine Forest, Pillar Rocks, Coaker's Walk, Bryant Park, Lake." },
      { day: 5, title: "Hotel Checkout → Drive to Coimbatore → Drop", details: "Drive back to Coimbatore for onward journey." },
    ],
    image: "/assets/kk1.jpg",
  },
  {
    id: "ooty-wayanad",
    title: "Ooty & Wayanad Tour Package",
    duration: "5 Days / 4 Nights",
    slug: "wayanad-tour-packages",
    description: "Experience the beauty of Ooty and Wayanad with stunning nature and wildlife.",
    highlights: ["2 Nights Ooty", "2 Nights Wayanad", "Pykara Sightseeing", "Wayanad Exploration"],
    itinerary: [
      { day: 1, title: "Ooty / Coimbatore Pickup → Drive to Ooty → Coonoor Sightseeing → Hotel", details: "Pickup and scenic drive with Coonoor stops." },
      { day: 2, title: "Hotel Pickup → Ooty Local Sightseeing → Hotel", details: "Full day Ooty exploration." },
      { day: 3, title: "Hotel Checkout → Drive to Wayanad → Pykara on the Way → Hotel", details: "Scenic drive through Pykara to Wayanad." },
      { day: 4, title: "Wayanad Hotel Pickup → Local Sightseeing → Hotel", details: "Edakkal Caves, Karapuzha Dam, Banasura Dam, Pookode Lake." },
      { day: 5, title: "Hotel Checkout → Drive to Coimbatore/Calicut → Drop", details: "Drop at airport or railway station." },
    ],
    image: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800&q=80",
  },
  {
    id: "ooty-mysore",
    title: "Ooty & Mysore Tour Package",
    duration: "5 Days / 4 Nights",
    slug: "mysore-tour-packages",
    description: "Combine the hill station charm of Ooty with the royal heritage of Mysore.",
    highlights: ["2 Nights Ooty", "2 Nights Mysore", "Coonoor Sightseeing", "Mysore Palace Tour"],
    itinerary: [
      { day: 1, title: "Coimbatore Pickup → Drive to Ooty → Coonoor Sightseeing → Hotel", details: "Pickup and drive through Coonoor to Ooty." },
      { day: 2, title: "Hotel Pickup → Ooty Local Sightseeing → Hotel", details: "Full day Ooty sightseeing." },
      { day: 3, title: "Hotel Checkout → Drive to Mysore → Pykara on the Way → Hotel", details: "Scenic drive via Pykara to Mysore." },
      { day: 4, title: "Mysore Hotel Pickup → Local Sightseeing → Hotel", details: "Mysore Palace, Zoo, Chamundeshwari Temple, Brindavan Gardens." },
      { day: 5, title: "Hotel Checkout → Remaining Mysore Sightseeing → Drop", details: "Remaining attractions and drop at Mysore/Bangalore." },
    ],
    image: "https://images.unsplash.com/photo-1600100397608-e1e5e3c7e4e3?w=800&q=80",
  },
];

export interface RoundTrip {
  id: string;
  title: string;
  route: string;
  destinations: string[];
  image: string;
}

export const ROUND_TRIPS: RoundTrip[] = [
  {
    id: "trip-a",
    title: "Package A",
    route: "Bangalore → Mysore → Coorg → Wayanad → Ooty → Kodaikanal → Coimbatore",
    destinations: ["Bangalore", "Mysore", "Coorg", "Wayanad", "Ooty", "Kodaikanal", "Coimbatore"],
    image: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800&q=80",
  },
  {
    id: "trip-b",
    title: "Package B",
    route: "Coimbatore → Ooty → Wayanad → Coorg → Mysore → Bangalore",
    destinations: ["Coimbatore", "Ooty", "Wayanad", "Coorg", "Mysore", "Bangalore"],
    image: "https://images.unsplash.com/photo-1556679343-c7306c1976bc?w=800&q=80",
  },
  {
    id: "trip-c",
    title: "Package C",
    route: "Coimbatore → Ooty → Kodaikanal → Madurai → Rameshwaram → Madurai Drop",
    destinations: ["Coimbatore", "Ooty", "Kodaikanal", "Madurai", "Rameshwaram"],
    image: "https://images.unsplash.com/photo-1596394723269-e1b58a1e6d8a?w=800&q=80",
  },
];

export const OUTSTATION_DESTINATIONS = [
  "Coimbatore", "Mysore", "Bangalore", "Coorg", "Wayanad",
  "Kodaikanal", "Rameshwaram", "Chennai", "Madurai", "All Over South India",
];

export const NAV_LINKS = [
  { label: "Home", href: "/" },
  { label: "Ooty Packages", href: "/ooty-tour-packages" },
  { label: "Ooty Sightseeing", href: "/ooty-sightseeing" },
  { label: "Kodaikanal", href: "/kodaikanal-tour-packages" },
  { label: "Wayanad", href: "/wayanad-tour-packages" },
  { label: "Mysore", href: "/mysore-tour-packages" },
  { label: "Services", href: "/services" },
  { label: "Gallery", href: "/gallery" },
  { label: "Contact", href: "/contact" },
];

export const SERVICES = [
  { title: "Ooty Local Sightseeing", description: "Comfortable sightseeing around Ooty and nearby destinations.", icon: "eye" },
  { title: "Outstation Pickup & Drop", description: "Pickup and drop services across major South Indian destinations.", icon: "map" },
  { title: "Airport Pickup & Drop", description: "Coimbatore, Calicut and other convenient airports.", icon: "plane" },
  { title: "Railway Station Pickup & Drop", description: "Convenient railway station transfers.", icon: "train" },
  { title: "Auto Service", description: `Contact Zubair: ${CONTACTS.zubair.displayPhone}`, icon: "car" },
  { title: "Homestay", description: `Contact Samsudheen: ${CONTACTS.samsudheen.displayPhone}`, icon: "home" },
  { title: "Customized Tours", description: "Build your own itinerary according to your travel requirements.", icon: "settings" },
];

export const GALLERY_CATEGORIES = [
  "All", "Ooty", "Coonoor", "Pykara", "Avalanche", "Kodaikanal", "Wayanad", "Mysore", "Vehicles",
];

export const GALLERY_ITEMS = [
  // Ooty
  { id: 1, category: "Ooty", title: "Doddabetta Peak", image: "/assets/121.jpg" },
  { id: 2, category: "Ooty", title: "Tea Museum", image: "/assets/212.jpg" },
  { id: 3, category: "Ooty", title: "Wax Museum", image: "/assets/313.jpg" },
  { id: 4, category: "Ooty", title: "Botanical Garden", image: "/assets/41.jpg" },
  { id: 5, category: "Ooty", title: "Rose Garden", image: "/assets/51.jpg" },
  { id: 6, category: "Ooty", title: "Thread Garden", image: "/assets/61.jpg" },
  { id: 7, category: "Ooty", title: "Ooty Lake", image: "/assets/71.jpg" },
  // Coonoor
  { id: 8, category: "Coonoor", title: "Valley View", image: "/assets/kv.jpg" },
  { id: 9, category: "Coonoor", title: "MRC Outer View", image: "/assets/kv1.jpg" },
  { id: 10, category: "Coonoor", title: "Golf View", image: "/assets/kv2.jpg" },
  { id: 11, category: "Coonoor", title: "Sims Park", image: "/assets/kv3.jpg" },
  { id: 12, category: "Coonoor", title: "Tea Garden", image: "/assets/kv4.jpg" },
  { id: 13, category: "Coonoor", title: "Lamb's Rock", image: "/assets/kv5.jpg" },
  { id: 14, category: "Coonoor", title: "Dolphin's Nose View", image: "/assets/kv6.jpg" },
  // Pykara
  { id: 15, category: "Pykara", title: "Golf View", image: "/assets/pk1.jpg" },
  { id: 16, category: "Pykara", title: "Pine Forest", image: "/assets/pk2.jpg" },
  { id: 17, category: "Pykara", title: "Tree Park", image: "/assets/pk3.jpg" },
  { id: 18, category: "Pykara", title: "Shooting Spot", image: "/assets/pk4.jpg" },
  { id: 19, category: "Pykara", title: "Pykara Lake", image: "/assets/pk5.jpg" },
  { id: 20, category: "Pykara", title: "Pykara Waterfalls", image: "/assets/pk6.jpg" },
  // Avalanche
  { id: 21, category: "Avalanche", title: "Carnhill Forest", image: "/assets/a1.jpg" },
  { id: 22, category: "Avalanche", title: "Emerald Lake Outer View", image: "/assets/a2.jpg" },
  { id: 23, category: "Avalanche", title: "Avalanche Lake", image: "/assets/a3.jpg" },
  { id: 24, category: "Avalanche", title: "Avalanche Safari", image: "/assets/a4.jpg" },
  { id: 25, category: "Avalanche", title: "Karnataka Garden", image: "/assets/a5.jpg" },
  // Kodaikanal
  { id: 26, category: "Kodaikanal", title: "Green Valley View Point", image: "/assets/q1.jpg" },
  { id: 27, category: "Kodaikanal", title: "Guna Caves", image: "/assets/q2.jpg" },
  { id: 28, category: "Kodaikanal", title: "Pine Forest", image: "/assets/q3.jpg" },
  { id: 29, category: "Kodaikanal", title: "Pillar Rocks", image: "/assets/q4.jpg" },
  { id: 30, category: "Kodaikanal", title: "Coaker's Walk", image: "/assets/q5.jpg" },
  { id: 31, category: "Kodaikanal", title: "Bryant Park", image: "/assets/q6.jpg" },
  { id: 32, category: "Kodaikanal", title: "Kodaikanal Lake", image: "/assets/q7.jpg" },
  // Wayanad
  { id: 33, category: "Wayanad", title: "Edakkal Caves", image: "/assets/p1.jpg" },
  { id: 34, category: "Wayanad", title: "Karapuzha Dam", image: "/assets/p2.jpg" },
  { id: 35, category: "Wayanad", title: "Banasura Dam", image: "/assets/p3.jpg" },
  { id: 36, category: "Wayanad", title: "Pookode Lake", image: "/assets/p4.jpg" },
  // Mysore
  { id: 37, category: "Mysore", title: "Mysore Palace", image: "/assets/m1.jpg" },
  { id: 38, category: "Mysore", title: "Mysore Zoo", image: "/assets/m2.jpg" },
  { id: 39, category: "Mysore", title: "Fish Aquarium", image: "/assets/m3.jpg" },
  { id: 40, category: "Mysore", title: "Chamundeshwari Temple", image: "/assets/m4.jpg" },
  { id: 41, category: "Mysore", title: "Sand Museum", image: "/assets/m5.jpg" },
  { id: 42, category: "Mysore", title: "St. Philomena's Church", image: "/assets/m6.jpg" },
  { id: 43, category: "Mysore", title: "Brindavan Gardens", image: "/assets/m7.jpg" },
  // Vehicles
  { id: 44, category: "Vehicles", title: "Travel Vehicle", image: "https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?w=600&q=80" },
];
